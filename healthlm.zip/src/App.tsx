/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  MapPin, 
  Calendar, 
  Clock, 
  User, 
  Stethoscope, 
  CreditCard,
  ChevronDown,
  Search,
  ExternalLink,
  LogOut,
  Lock,
  Mail,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Types
interface UserData {
  id: number;
  email: string;
  name: string;
  age: number;
  gender: string;
}

interface Appointment {
  id: string;
  patient: string;
  doctor: string;
  date: string;
  time: string;
  fee: string;
  location: string;
  status: 'Paid' | 'Pending';
}

const SPECIALIZATIONS = [
  "General Medicine",
  "Cardiology",
  "Neurology",
  "Orthopedics",
  "Pediatrics",
  "Gynecology & Obstetrics",
  "Ophthalmology",
  "ENT",
  "Psychiatry",
  "Oncology",
  "Dermatology",
  "Nephrology",
  "Pulmonology",
  "Endocrinology",
  "General Surgery"
];

const REGION_DATA: Record<string, string[]> = {
  "Andhra Pradesh": ["Tirupati", "Araku Valley", "Vijayawada", "Borra Caves"],
  "Arunachal Pradesh": ["Tawang", "Ziro Valley", "Bomdila", "Sela Pass"],
  "Assam": ["Kaziranga", "Majuli", "Sivasagar", "Manas NP"],
  "Bihar": ["Bodh Gaya", "Nalanda", "Rajgir", "Vaishali"],
  "Chhattisgarh": ["Chitrakoot Falls", "Sirpur", "Bhoramdeo", "Barnawapara"],
  "Goa": ["Baga Beach", "Calangute", "Dudhsagar Falls", "Fort Aguada"],
  "Gujarat": ["Somnath", "Dwarka", "Gir NP", "Rann of Kutch"],
  "Haryana": ["Kurukshetra", "Pinjore Gardens", "Morni Hills", "Sultanpur NP"],
  "Himachal Pradesh": ["Manali", "Dharamshala", "Kasol", "Rohtang Pass"],
  "Jharkhand": ["Hundru Falls", "Betla NP", "Dassam Falls", "Netarhat"],
  "Karnataka": ["Mysore", "Hampi", "Coorg", "Jog Falls"],
  "Kerala": ["Munnar", "Alleppey", "Wayanad", "Kochi"],
  "Madhya Pradesh": ["Khajuraho", "Gwalior", "Sanchi", "Kanha NP"],
  "Maharashtra": ["Pune", "Lonavala", "Ajanta", "Ellora"],
  "Manipur": ["Loktak Lake", "Khongjom", "Andro", "Ukhrul"],
  "Meghalaya": ["Shillong", "Cherrapunji", "Dawki", "Mawlynnong", "Umiam Lake"],
  "Mizoram": ["Vantawng Falls", "Reiek", "Phawngpui", "Champhai"],
  "Nagaland": ["Dzükou Valley", "Khonoma", "Kisama", "Mt. Japfu"],
  "Odisha": ["Puri", "Konark", "Chilika Lake", "Cuttack"],
  "Punjab": ["Amritsar", "Patiala", "Ludhiana", "Anandpur Sahib"],
  "Rajasthan": ["Udaipur", "Jaisalmer", "Pushkar", "Jodhpur"],
  "Sikkim": ["Pelling", "Nathula", "Tsomgo Lake", "Ravangla"],
  "Tamil Nadu": ["Madurai", "Ooty", "Kodaikanal", "Mahabalipuram"],
  "Telangana": ["Warangal", "Karimnagar", "Nizamabad", "Nagarjuna Sagar"],
  "Tripura": ["Udaipur", "Neermahal", "Jampui Hills", "Unakoti"],
  "Uttar Pradesh": ["Agra", "Varanasi", "Mathura", "Ayodhya"],
  "Uttarakhand": ["Nainital", "Rishikesh", "Haridwar", "Mussoorie"],
  "West Bengal": ["Kolkata", "Darjeeling", "Sundarbans", "Digha", "Kalimpong"],
  "Andaman & Nicobar Islands": ["Havelock", "Neil Island", "Ross Island", "Radhanagar Beach"],
  "Chandigarh": ["Rock Garden", "Sukhna Lake", "Rose Garden", "Leisure Valley"],
  "Dadra & Nagar Haveli and Daman & Diu": ["Diu Fort", "Jampore Beach", "Silvassa", "St. Paul’s Church"],
  "Delhi": ["Red Fort", "Qutub Minar", "Lotus Temple", "Akshardham"],
  "Jammu & Kashmir": ["Gulmarg", "Pahalgam", "Sonamarg", "Vaishno Devi"],
  "Ladakh": ["Pangong Lake", "Nubra Valley", "Tso Moriri", "Khardung La"],
  "Lakshadweep": ["Agatti", "Bangaram", "Minicoy", "Kadmat"],
  "Puducherry": ["Auroville", "Paradise Beach", "Promenade", "Serenity"]
};

const DOCTOR_NAMES = ["Sharma", "Verma", "Gupta", "Malhotra", "Iyer", "Reddy", "Patel", "Khan", "Singh", "Das", "Joshi", "Kulkarni", "Nair", "Bose", "Chatterjee"];
const FIRST_NAMES = ["Aarav", "Aditi", "Arjun", "Ananya", "Ishaan", "Kavya", "Rohan", "Sanya", "Vihaan", "Zoya", "Rahul", "Priya", "Vikram", "Neha", "Amit"];
const DEGREES = ["MBBS, MD", "MBBS, MS", "MBBS, DNB", "MD, DM", "MS, MCh"];
const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

interface Doctor {
  id: string;
  name: string;
  degree: string;
  cv: string;
  timings: string;
  day: string;
  location: string;
  address: string;
  fee: string;
  bookingLimit: number;
}

const AuthModal = ({ isOpen, onClose, onAuthSuccess }: { isOpen: boolean, onClose: () => void, onAuthSuccess: (user: UserData, token: string) => void }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    age: '',
    gender: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const endpoint = isLogin ? '/api/auth/login' : '/api/auth/signup';
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await response.json();
      if (response.ok) {
        onAuthSuccess(data.user, data.token);
        onClose();
      } else {
        setError(data.error || 'Authentication failed');
      }
    } catch (err) {
      setError('Connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden"
      >
        <div className="p-8 md:p-12">
          <div className="text-center space-y-2 mb-8">
            <h2 className="text-3xl font-display font-bold text-slate-900">
              {isLogin ? 'Welcome Back' : 'Create Account'}
            </h2>
            <p className="text-slate-500 font-light">
              {isLogin ? 'Log in to manage your appointments' : 'Join our healthcare network today'}
            </p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 text-red-600 text-sm rounded-2xl border border-red-100 font-medium">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <>
                <div className="relative">
                  <User className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                  <input 
                    type="text" 
                    placeholder="Full Name"
                    required
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl pl-14 pr-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all"
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <input 
                    type="number" 
                    placeholder="Age"
                    required
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all"
                    value={formData.age}
                    onChange={e => setFormData({...formData, age: e.target.value})}
                  />
                  <select 
                    required
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all"
                    value={formData.gender}
                    onChange={e => setFormData({...formData, gender: e.target.value})}
                  >
                    <option value="">Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </>
            )}
            <div className="relative">
              <Mail className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
              <input 
                type="email" 
                placeholder="Email Address"
                required
                className="w-full bg-slate-50 border border-slate-100 rounded-2xl pl-14 pr-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all"
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
              <input 
                type="password" 
                placeholder="Password"
                required
                className="w-full bg-slate-50 border border-slate-100 rounded-2xl pl-14 pr-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all"
                value={formData.password}
                onChange={e => setFormData({...formData, password: e.target.value})}
              />
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-4 rounded-2xl shadow-xl shadow-brand-200 transition-all flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (isLogin ? 'Log In' : 'Sign Up')}
            </button>
          </form>

          <div className="mt-8 space-y-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-100"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase tracking-widest font-bold">
                <span className="bg-white px-4 text-slate-400">Or continue with</span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <button 
                onClick={() => alert('Social login integration requires API credentials. Please configure GOOGLE_CLIENT_ID in .env')}
                className="flex items-center justify-center py-3 border border-slate-100 rounded-2xl hover:bg-slate-50 transition-colors"
              >
                <img src="https://www.svgrepo.com/show/475656/google-color.svg" className="w-5 h-5" alt="Google" />
              </button>
              <button 
                onClick={() => alert('Social login integration requires API credentials. Please configure FACEBOOK_CLIENT_ID in .env')}
                className="flex items-center justify-center py-3 border border-slate-100 rounded-2xl hover:bg-slate-50 transition-colors"
              >
                <img src="https://www.svgrepo.com/show/475647/facebook-color.svg" className="w-5 h-5" alt="Facebook" />
              </button>
              <button 
                onClick={() => alert('Social login integration requires API credentials. Please configure TWITTER_CLIENT_ID in .env')}
                className="flex items-center justify-center py-3 border border-slate-100 rounded-2xl hover:bg-slate-50 transition-colors"
              >
                <img src="https://www.svgrepo.com/show/475689/twitter-color.svg" className="w-5 h-5" alt="Twitter" />
              </button>
            </div>

            <div className="text-center">
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="text-sm font-medium text-slate-500 hover:text-brand-600 transition-colors"
              >
                {isLogin ? "Don't have an account? Sign Up" : "Already have an account? Log In"}
              </button>
            </div>
          </div>
          
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 text-slate-300 hover:text-slate-500 transition-colors"
          >
            <Plus className="w-6 h-6 rotate-45" />
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState<UserData | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('healthlm_token'));
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [appointments, setAppointments] = useState<Appointment[]>([]);

  const [selectedRegion, setSelectedRegion] = useState('');
  const [selectedArea, setSelectedArea] = useState('');
  const [selectedSpec, setSelectedSpec] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [doctorBookings, setDoctorBookings] = useState<Record<string, number>>({});

  // Deterministic doctor generation based on selection
  const availableDoctors = React.useMemo(() => {
    if (!selectedSpec || !selectedRegion || !selectedArea) return [];
    
    const doctors: Doctor[] = [];
    const seed = (selectedSpec.length + selectedRegion.length + selectedArea.length);
    
    for (let i = 0; i < 5; i++) {
      const firstName = FIRST_NAMES[(seed + i) % FIRST_NAMES.length];
      const lastName = DOCTOR_NAMES[(seed * (i + 1)) % DOCTOR_NAMES.length];
      const degree = DEGREES[(seed + i) % DEGREES.length];
      const day = DAYS[(seed + i) % DAYS.length];
      const startHour = 9 + (i % 4);
      const endHour = startHour + 4;
      
      doctors.push({
        id: `doc-${selectedSpec}-${selectedRegion}-${selectedArea}-${i}`,
        name: `Dr. ${firstName} ${lastName}`,
        degree: degree,
        cv: `Specialist in ${selectedSpec} with over ${10 + i} years of clinical experience in advanced healthcare.`,
        timings: `${startHour}:00 AM - ${endHour}:00 PM`,
        day: day,
        location: `${selectedArea}, ${selectedRegion}`,
        address: `${100 + i}, Health Plaza, ${selectedArea}, ${selectedRegion}`,
        fee: `₹${500 + (i * 100)}`,
        bookingLimit: 3 // Each doctor can take 3 bookings
      });
    }
    return doctors;
  }, [selectedSpec, selectedRegion, selectedArea]);

  const [formData, setFormData] = useState({
    patientName: '',
    age: '',
    gender: '',
    diseaseDescription: '',
    date: '',
    time: '',
    paymentMethod: '',
    doctor: ''
  });

  // Auth & Data Fetching
  useEffect(() => {
    if (token) {
      fetchUser();
      fetchAppointments();
    }
  }, [token]);

  // Pre-fill form when user logs in
  useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        patientName: user.name,
        age: user.age.toString(),
        gender: user.gender
      }));
    }
  }, [user]);

  const fetchUser = async () => {
    try {
      const response = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setUser(data);
      } else {
        handleLogout();
      }
    } catch (err) {
      console.error('Failed to fetch user');
    }
  };

  const fetchAppointments = async () => {
    try {
      const response = await fetch('/api/appointments', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setAppointments(data);
      }
    } catch (err) {
      console.error('Failed to fetch appointments');
    }
  };

  const handleAuthSuccess = (userData: UserData, userToken: string) => {
    setUser(userData);
    setToken(userToken);
    localStorage.setItem('healthlm_token', userToken);
  };

  const handleLogout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('healthlm_token');
    setAppointments([]);
    setFormData({
      patientName: '',
      age: '',
      gender: '',
      diseaseDescription: '',
      date: '',
      time: '',
      paymentMethod: '',
      doctor: ''
    });
  };

  // Sync form doctor with selection
  React.useEffect(() => {
    if (selectedDoctor) {
      setFormData(prev => ({ ...prev, doctor: selectedDoctor.name }));
    }
  }, [selectedDoctor]);

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) {
      setIsAuthModalOpen(true);
      return;
    }

    const doctorName = selectedDoctor ? selectedDoctor.name : formData.doctor;
    if (!formData.patientName || !doctorName) {
      alert('Please fill in all required fields and select a doctor.');
      return;
    }

    if (selectedDoctor && (doctorBookings[selectedDoctor.id] || 0) >= selectedDoctor.bookingLimit) {
      alert('This doctor is already fully booked. Please select another doctor.');
      return;
    }

    const fee = selectedDoctor ? selectedDoctor.fee : '$100';
    
    const newAppointment: Appointment = {
      id: Math.random().toString(36).substr(2, 9),
      patient: formData.patientName,
      doctor: doctorName,
      date: formData.date,
      time: formData.time,
      fee: fee,
      location: selectedDoctor ? selectedDoctor.address : 'Main Clinic',
      status: 'Pending'
    };

    try {
      const response = await fetch('/api/appointments', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newAppointment)
      });

      if (response.ok) {
        // Update bookings count locally
        if (selectedDoctor) {
          setDoctorBookings(prev => ({
            ...prev,
            [selectedDoctor.id]: (prev[selectedDoctor.id] || 0) + 1
          }));
        }

        setAppointments([newAppointment, ...appointments]);
        
        // Reset all data to default
        setFormData({
          patientName: user?.name || '',
          age: user?.age.toString() || '',
          gender: user?.gender || '',
          diseaseDescription: '',
          date: '',
          time: '',
          paymentMethod: '',
          doctor: ''
        });
        setSelectedSpec('');
        setSelectedRegion('');
        setSelectedArea('');
        setSelectedDoctor(null);
        
        alert('Appointment Booked Successfully!');
      } else {
        alert('Failed to save appointment. Please try again.');
      }
    } catch (err) {
      alert('Connection error. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900">
      {/* 1. Top Section */}
      <header className="relative px-6 py-12 md:px-12 lg:px-24 overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-[600px] h-[600px] bg-brand-50 rounded-full blur-3xl opacity-50 -z-10" />
        <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/4 w-[400px] h-[400px] bg-blue-50 rounded-full blur-3xl opacity-50 -z-10" />

        <div className="flex items-center justify-between mb-16">
          <div className="flex items-center gap-2 text-brand-600 font-display font-bold text-2xl">
            <div className="bg-brand-600 p-1.5 rounded-lg">
              <Plus className="w-6 h-6 text-white" />
            </div>
            <span>HealthLm</span>
          </div>
          <div className="flex items-center gap-6">
            <nav className="hidden md:flex gap-8 text-sm font-medium text-slate-500">
              <a href="#" className="hover:text-brand-600 transition-colors">Find Doctors</a>
              <a href="#" className="hover:text-brand-600 transition-colors">Specializations</a>
              <a href="#" className="hover:text-brand-600 transition-colors">About Us</a>
            </nav>
            <div className="h-6 w-px bg-slate-200 hidden md:block" />
            {user ? (
              <div className="flex items-center gap-4">
                <div className="flex flex-col items-end hidden sm:flex">
                  <span className="text-xs font-bold text-slate-900">{user.name}</span>
                  <span className="text-[10px] text-slate-400 uppercase tracking-widest">Patient Dashboard</span>
                </div>
                <button 
                  onClick={handleLogout}
                  className="bg-slate-50 text-slate-600 p-2.5 rounded-xl hover:bg-slate-100 transition-colors"
                  title="Log Out"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setIsAuthModalOpen(true)}
                className="bg-brand-600 text-white px-6 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-brand-100 hover:bg-brand-700 transition-all active:scale-95"
              >
                Sign In
              </button>
            )}
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl"
        >
          <div className="space-y-6">
            <h1 className="text-5xl md:text-7xl font-display font-bold text-slate-900 tracking-tight leading-[1.1]">
              Your Health, <br />
              <span className="text-brand-600">Our Priority.</span>
            </h1>
            <p className="text-xl text-slate-500 leading-relaxed max-w-2xl font-light">
              Find specialized doctors, research symptoms, and book appointments instantly with the world's most trusted health care network.
            </p>
            <div className="flex gap-4 pt-4">
              <button 
                onClick={() => !user && setIsAuthModalOpen(true)}
                className="bg-white text-slate-700 border border-slate-200 px-8 py-4 rounded-2xl font-bold hover:bg-slate-50 transition-all"
              >
                Learn More
              </button>
            </div>
          </div>
        </motion.div>
      </header>

      <main className="px-6 md:px-12 lg:px-24 pb-24 space-y-24">
        
        {/* 2. Selection Section - Integrated Search Bar Feel */}
        <section className="relative -mt-12 z-20">
          <div className="bg-white p-4 md:p-6 rounded-[2.5rem] shadow-2xl shadow-slate-200/60 border border-slate-100 grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div className="space-y-2 px-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] ml-1">Specialization</label>
              <div className="relative group">
                <select 
                  value={selectedSpec}
                  onChange={(e) => {
                    setSelectedSpec(e.target.value);
                    setSelectedDoctor(null);
                  }}
                  className="w-full appearance-none bg-slate-50/50 border border-slate-100 rounded-2xl px-5 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium text-slate-700 group-hover:bg-slate-50"
                >
                  <option value="">Choose Specialization</option>
                  {SPECIALIZATIONS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                <ChevronDown className="absolute right-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 pointer-events-none" />
              </div>
            </div>

            <div className="space-y-2 px-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] ml-1">Region</label>
              <div className="relative group">
                <select 
                  value={selectedRegion}
                  onChange={(e) => {
                    setSelectedRegion(e.target.value);
                    setSelectedArea('');
                    setSelectedDoctor(null);
                  }}
                  className="w-full appearance-none bg-slate-50/50 border border-slate-100 rounded-2xl px-5 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium text-slate-700 group-hover:bg-slate-50"
                >
                  <option value="">Choose Region</option>
                  {Object.keys(REGION_DATA).map(r => <option key={r} value={r}>{r}</option>)}
                </select>
                <ChevronDown className="absolute right-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 pointer-events-none" />
              </div>
            </div>

            <div className="space-y-2 px-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] ml-1">Area</label>
              <div className="relative group">
                <select 
                  value={selectedArea}
                  onChange={(e) => {
                    setSelectedArea(e.target.value);
                    setSelectedDoctor(null);
                  }}
                  disabled={!selectedRegion}
                  className="w-full appearance-none bg-slate-50/50 border border-slate-100 rounded-2xl px-5 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium text-slate-700 disabled:opacity-50 group-hover:bg-slate-50"
                >
                  <option value="">Choose Area</option>
                  {selectedRegion && REGION_DATA[selectedRegion].map(a => <option key={a} value={a}>{a}</option>)}
                </select>
                <ChevronDown className="absolute right-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 pointer-events-none" />
              </div>
            </div>
          </div>
        </section>

        {/* Available Doctors Section */}
        <AnimatePresence>
          {availableDoctors.length > 0 && (
            <motion.section 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <div className="flex items-end justify-between">
                <div>
                  <h2 className="text-3xl font-display font-bold text-slate-900">Recommended Doctors</h2>
                  <p className="text-slate-500 mt-1 font-light">Top specialists in {selectedArea}, {selectedRegion}</p>
                </div>
                <div className="flex gap-2">
                  <div className="w-10 h-10 rounded-full bg-white border border-slate-100 flex items-center justify-center text-slate-400 cursor-pointer hover:bg-slate-50 transition-colors">
                    <ChevronDown className="w-5 h-5 rotate-90" />
                  </div>
                  <div className="w-10 h-10 rounded-full bg-white border border-slate-100 flex items-center justify-center text-slate-400 cursor-pointer hover:bg-slate-50 transition-colors">
                    <ChevronDown className="w-5 h-5 -rotate-90" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {availableDoctors.map((doc, idx) => {
                  const isBooked = (doctorBookings[doc.id] || 0) >= doc.bookingLimit;
                  return (
                    <motion.div 
                      key={doc.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      whileHover={!isBooked ? { y: -8 } : {}}
                      className={`group relative bg-white p-8 rounded-[2.5rem] border transition-all duration-500 ${
                        isBooked 
                          ? 'opacity-60 grayscale cursor-not-allowed border-slate-100'
                          : selectedDoctor?.id === doc.id 
                            ? 'border-brand-500 shadow-2xl shadow-brand-100 ring-4 ring-brand-50 cursor-pointer' 
                            : 'border-slate-100 hover:border-brand-200 shadow-xl shadow-slate-200/30 cursor-pointer'
                      }`}
                      onClick={() => {
                        if (isBooked) return;
                        if (!token) {
                          setIsAuthModalOpen(true);
                          return;
                        }
                        setSelectedDoctor(doc);
                      }}
                    >
                      <div className="flex justify-between items-start mb-8">
                        <div className="relative">
                          <div className="w-16 h-16 bg-brand-50 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110 duration-500">
                            <Stethoscope className="w-8 h-8 text-brand-600" />
                          </div>
                          <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-white rounded-lg shadow-sm border border-slate-50 flex items-center justify-center">
                            <div className="w-2 h-2 bg-brand-500 rounded-full animate-pulse" />
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          {selectedDoctor?.id === doc.id && (
                            <motion.span 
                              initial={{ scale: 0.8 }}
                              animate={{ scale: 1 }}
                              className="bg-brand-600 text-white text-[10px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full shadow-lg shadow-brand-200"
                            >
                              Selected ✅
                            </motion.span>
                          )}
                          {isBooked && (
                            <span className="bg-red-500 text-white text-[10px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full">
                              Fully Booked
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="space-y-1 mb-6">
                        <h3 className="text-2xl font-display font-bold text-slate-900 group-hover:text-brand-600 transition-colors">{doc.name}</h3>
                        <p className="text-brand-600 font-bold text-xs uppercase tracking-widest">{doc.degree}</p>
                      </div>

                      <p className="text-slate-400 text-sm mb-8 leading-relaxed font-light line-clamp-2">{doc.cv}</p>
                      
                      <div className="flex items-center justify-between mb-8 bg-slate-50/50 p-4 rounded-2xl border border-slate-50">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Availability</span>
                        <div className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-brand-500 rounded-full" />
                          <span className={`text-xs font-bold ${isBooked ? 'text-red-500' : 'text-brand-600'}`}>
                            {doctorBookings[doc.id] || 0}/{doc.bookingLimit} Booked
                          </span>
                        </div>
                      </div>

                      <div className="space-y-4 mb-8">
                        <div className="flex items-center gap-3 text-sm text-slate-500">
                          <div className="w-8 h-8 rounded-xl bg-white border border-slate-100 flex items-center justify-center shadow-sm">
                            <Calendar className="w-4 h-4 text-slate-400" />
                          </div>
                          <span className="font-medium">{doc.day}</span>
                        </div>
                        <div className="flex items-center gap-3 text-sm text-slate-500">
                          <div className="w-8 h-8 rounded-xl bg-white border border-slate-100 flex items-center justify-center shadow-sm">
                            <Clock className="w-4 h-4 text-slate-400" />
                          </div>
                          <span className="font-medium">{doc.timings}</span>
                        </div>
                        <div className="flex items-center gap-3 text-sm text-slate-500">
                          <div className="w-8 h-8 rounded-xl bg-white border border-slate-100 flex items-center justify-center shadow-sm">
                            <MapPin className="w-4 h-4 text-slate-400" />
                          </div>
                          <span className="font-medium truncate">{doc.address}</span>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center pt-6 border-t border-slate-50">
                        <div className="flex flex-col">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Consultation Fee</span>
                          <span className="text-2xl font-display font-bold text-slate-900">{doc.fee}</span>
                        </div>
                        <button 
                          disabled={isBooked}
                          className={`px-8 py-3 rounded-2xl font-bold text-sm transition-all duration-300 ${
                            isBooked
                              ? 'bg-slate-100 text-slate-300'
                              : selectedDoctor?.id === doc.id 
                                ? 'bg-brand-600 text-white shadow-lg shadow-brand-200' 
                                : 'bg-slate-900 text-white hover:bg-brand-600 hover:shadow-lg hover:shadow-brand-200'
                          }`}
                        >
                          {isBooked ? 'Full' : selectedDoctor?.id === doc.id ? 'Selected' : 'Book Now'}
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.section>
          )}
        </AnimatePresence>

        {/* 3. Appointment Booking Form - Premium Card Design */}
        <section className="max-w-5xl mx-auto">
          <div className="bg-white rounded-[3rem] shadow-2xl shadow-slate-200/50 border border-slate-100 overflow-hidden flex flex-col md:flex-row">
            <div className="md:w-1/3 bg-slate-900 p-12 text-white flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-full bg-brand-600/10 -z-10" />
              <div className="space-y-6">
                <div className="w-12 h-12 bg-brand-600 rounded-2xl flex items-center justify-center">
                  <Calendar className="w-6 h-6" />
                </div>
                <h2 className="text-4xl font-display font-bold leading-tight">Book Your <br />Appointment</h2>
                <p className="text-slate-400 font-light leading-relaxed">Fill in the details to secure your spot with our world-class medical professionals.</p>
              </div>
              <div className="space-y-4 pt-12">
                <div className="flex items-center gap-3 text-sm text-slate-400">
                  <div className="w-2 h-2 bg-brand-500 rounded-full" />
                  <span>Instant Confirmation</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-slate-400">
                  <div className="w-2 h-2 bg-brand-500 rounded-full" />
                  <span>Verified Specialists</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-slate-400">
                  <div className="w-2 h-2 bg-brand-500 rounded-full" />
                  <span>Secure Payments</span>
                </div>
              </div>
            </div>
            
            <form onSubmit={handleBooking} className="md:w-2/3 p-12 grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Patient Name</label>
                <input 
                  type="text" 
                  placeholder="Full Name"
                  className="w-full bg-slate-50/50 border border-slate-100 rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium text-slate-700 placeholder:text-slate-300"
                  value={formData.patientName}
                  onChange={e => setFormData({...formData, patientName: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Age</label>
                <input 
                  type="text" 
                  placeholder="Years"
                  className="w-full bg-slate-50/50 border border-slate-100 rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium text-slate-700 placeholder:text-slate-300"
                  value={formData.age}
                  onChange={e => setFormData({...formData, age: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Gender</label>
                <div className="relative">
                  <select 
                    className="w-full appearance-none bg-slate-50/50 border border-slate-100 rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium text-slate-700"
                    value={formData.gender}
                    onChange={e => setFormData({...formData, gender: e.target.value})}
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                  <ChevronDown className="absolute right-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 pointer-events-none" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Appointment Date</label>
                <input 
                  type="date" 
                  className="w-full bg-slate-50/50 border border-slate-100 rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium text-slate-700"
                  value={formData.date}
                  onChange={e => setFormData({...formData, date: e.target.value})}
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Disease Description</label>
                <textarea 
                  rows={3}
                  placeholder="Briefly describe your symptoms..."
                  className="w-full bg-slate-50/50 border border-slate-100 rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium text-slate-700 resize-none placeholder:text-slate-300"
                  value={formData.diseaseDescription}
                  onChange={e => setFormData({...formData, diseaseDescription: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Time</label>
                <input 
                  type="time" 
                  className="w-full bg-slate-50/50 border border-slate-100 rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium text-slate-700"
                  value={formData.time}
                  onChange={e => setFormData({...formData, time: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Payment Method</label>
                <div className="relative">
                  <select 
                    className="w-full appearance-none bg-slate-50/50 border border-slate-100 rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all font-medium text-slate-700"
                    value={formData.paymentMethod}
                    onChange={e => setFormData({...formData, paymentMethod: e.target.value})}
                  >
                    <option value="">Select Method</option>
                    <option value="Cash">Cash</option>
                    <option value="NetBanking">NetBanking</option>
                    <option value="UPI">UPI</option>
                    <option value="Credit Card">Credit Card</option>
                  </select>
                  <ChevronDown className="absolute right-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300 pointer-events-none" />
                </div>
              </div>

              <div className="md:col-span-2 pt-6">
                <div className="flex items-center justify-between bg-slate-50 p-6 rounded-3xl border border-slate-100 mb-8">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm border border-slate-50">
                      <User className="w-6 h-6 text-brand-600" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Selected Specialist</p>
                      <p className="font-display font-bold text-slate-900">{selectedDoctor ? selectedDoctor.name : 'No Doctor Selected'}</p>
                    </div>
                  </div>
                  {selectedDoctor && (
                    <button 
                      type="button"
                      onClick={() => setSelectedDoctor(null)}
                      className="text-[10px] font-bold text-brand-600 uppercase tracking-widest hover:text-brand-700 transition-colors"
                    >
                      Change
                    </button>
                  )}
                </div>

                <button 
                  type="submit"
                  className="w-full bg-brand-600 hover:bg-brand-700 text-white font-bold py-5 rounded-[2rem] shadow-xl shadow-brand-200 transition-all active:scale-[0.98] text-lg"
                >
                  Confirm Appointment
                </button>
              </div>
            </form>
          </div>
        </section>

        {/* 4. Appointment History Section - Modern Data Grid */}
        <section className="space-y-8">
          <div className="flex items-end justify-between">
            <div>
              <h2 className="text-3xl font-display font-bold text-slate-900">Appointment History</h2>
              <p className="text-slate-500 mt-1 font-light">Track your past and upcoming medical visits</p>
            </div>
            <button className="text-sm font-bold text-brand-600 hover:text-brand-700 transition-colors flex items-center gap-2">
              Export History <ExternalLink className="w-4 h-4" />
            </button>
          </div>

          <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/30 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-50">
                    <th className="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Patient</th>
                    <th className="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Doctor</th>
                    <th className="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Schedule</th>
                    <th className="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Location</th>
                    <th className="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Fee</th>
                    <th className="px-8 py-6 text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Status</th>
                  </tr>
                </thead>
                <tbody>
                  <AnimatePresence mode="popLayout">
                    {appointments.map((apt) => (
                      <motion.tr 
                        key={apt.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="border-b border-slate-50 hover:bg-slate-50/30 transition-colors group"
                      >
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-bold text-xs">
                              {apt.patient.charAt(0)}
                            </div>
                            <span className="font-display font-bold text-slate-800">{apt.patient}</span>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-2">
                            <Stethoscope className="w-4 h-4 text-brand-500" />
                            <span className="text-slate-600 font-medium">{apt.doctor}</span>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 text-xs text-slate-800 font-bold">
                              <Calendar className="w-3 h-3" />
                              {apt.date}
                            </div>
                            <div className="flex items-center gap-2 text-[10px] text-slate-400">
                              <Clock className="w-3 h-3" />
                              {apt.time}
                            </div>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-2 text-xs text-slate-500 max-w-[200px] truncate">
                            <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                            {apt.location}
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <span className="font-display font-bold text-slate-900">{apt.fee}</span>
                        </td>
                        <td className="px-8 py-6">
                          <span className={`px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                            apt.status === 'Paid' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'
                          }`}>
                            {apt.status}
                          </span>
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* 5. Location Section - Refined Minimal Design */}
        <section className="space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-4">
            <h2 className="text-3xl font-display font-bold text-slate-900">Visit Our Clinic</h2>
            <p className="text-slate-500 font-light">Find us at our state-of-the-art medical facilities designed for your comfort and care.</p>
          </div>
          
          <div className="max-w-3xl mx-auto">
            <div className="bg-white p-12 rounded-[3rem] space-y-10 flex flex-col items-center border border-slate-100 shadow-2xl shadow-slate-200/50 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1.5 bg-brand-600" />
              
              <div className="w-20 h-20 bg-brand-50 rounded-[2rem] flex items-center justify-center shadow-inner">
                <MapPin className="text-brand-600 w-10 h-10" />
              </div>

              <div className="space-y-4 text-center">
                <h3 className="text-2xl font-display font-bold text-slate-900">
                  {selectedDoctor ? 'Clinic Address' : 'Main Medical Center'}
                </h3>
                <div className="flex flex-col items-center gap-2">
                  <p className="text-slate-500 font-light max-w-md">
                    {selectedDoctor 
                      ? `Consult with ${selectedDoctor.name} at their specialized facility.`
                      : 'Our main facility is located in the heart of the Medical District.'}
                  </p>
                  <div className="bg-slate-50 px-6 py-3 rounded-2xl border border-slate-100 mt-4">
                    <p className="text-slate-800 font-bold">
                      {selectedDoctor ? selectedDoctor.address : '123 Wellness Ave, Medical District, NY 10001'}
                    </p>
                  </div>
                </div>
              </div>

              <button 
                onClick={() => window.open(`https://www.google.com/maps/search/${encodeURIComponent(selectedDoctor?.address || 'Medical District')}`, '_blank')}
                className="flex items-center justify-center gap-3 w-full max-w-xs bg-slate-900 hover:bg-brand-600 text-white font-bold py-5 rounded-[2rem] transition-all shadow-xl shadow-slate-200 hover:shadow-brand-200 active:scale-95"
              >
                <ExternalLink className="w-5 h-5" />
                Open in Maps
              </button>
            </div>
          </div>
        </section>

      </main>

      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
        onAuthSuccess={handleAuthSuccess}
      />

      <footer className="bg-slate-900 text-slate-400 py-20 px-6 md:px-12 lg:px-24">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-1 md:col-span-2 space-y-6">
              <div className="flex items-center gap-2 text-white font-display font-bold text-2xl">
                <div className="bg-brand-600 p-1 rounded-lg">
                  <Plus className="w-5 h-5" />
                </div>
                <span>HealthLm</span>
              </div>
              <p className="max-w-sm font-light leading-relaxed">
                Empowering patients with instant access to world-class healthcare. Book, track, and manage your health journey with ease.
              </p>
            </div>
            <div className="space-y-6">
              <h4 className="text-white font-bold text-sm uppercase tracking-widest">Quick Links</h4>
              <ul className="space-y-4 text-sm">
                <li><a href="#" className="hover:text-brand-500 transition-colors">Find a Doctor</a></li>
                <li><a href="#" className="hover:text-brand-500 transition-colors">Specializations</a></li>
                <li><a href="#" className="hover:text-brand-500 transition-colors">Health Articles</a></li>
              </ul>
            </div>
            <div className="space-y-6">
              <h4 className="text-white font-bold text-sm uppercase tracking-widest">Support</h4>
              <ul className="space-y-4 text-sm">
                <li><a href="#" className="hover:text-brand-500 transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-brand-500 transition-colors">FAQs</a></li>
                <li><a href="#" className="hover:text-brand-500 transition-colors">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
          <div className="pt-12 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-xs font-light tracking-wider uppercase">© 2024 HealthLm Healthcare Network. All rights reserved.</p>
            <div className="flex gap-8">
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center hover:bg-brand-600 transition-colors cursor-pointer">
                <Search className="w-4 h-4 text-white" />
              </div>
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center hover:bg-brand-600 transition-colors cursor-pointer">
                <User className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
